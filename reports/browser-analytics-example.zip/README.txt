JEV Checkers analytics export
All recorded turns, with no sampling.
Verify replay.json using the source package: npm run verify -- replay.json
CSV string fields are escaped against spreadsheet formula injection.
Trust: hash integrity is not a signature or proof of official score provenance.
Human elapsed time may include network delay and time away.
Provider certainty and heuristic values are not win probabilities.
Missing usage/cost stays unknown. Operations are available only for owned server records.
